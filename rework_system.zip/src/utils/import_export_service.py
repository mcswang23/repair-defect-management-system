# 数据导入导出服务

import pandas as pd
from sqlalchemy.orm import Session
from datetime import date
from typing import List, Dict, Any
import os

from src.models.models import DefectiveItem, RepairRecord, CauseAnalysis
from src.utils.data_service import DataService

class ImportExportService:
    """数据导入导出服务类"""
    
    @staticmethod
    def export_defective_items(db: Session, file_path: str) -> bool:
        """导出不良品记录到CSV或Excel文件"""
        try:
            # 查询所有不良品记录
            items = db.query(DefectiveItem).all()
            
            # 准备数据
            data = []
            for item in items:
                data.append({
                    "id": item.id,
                    "item_code": item.item_code,
                    "item_name": item.item_name,
                    "quantity": item.quantity,
                    "defect_date": item.defect_date.strftime("%Y-%m-%d"),
                    "defect_location": item.defect_location,
                    "reported_by": item.reported_by,
                    "description": item.description,
                    "status": item.status,
                    "created_at": item.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                    "updated_at": item.updated_at.strftime("%Y-%m-%d %H:%M:%S")
                })
            
            # 创建DataFrame
            df = pd.DataFrame(data)
            
            # 根据文件扩展名导出
            if file_path.endswith('.csv'):
                df.to_csv(file_path, index=False, encoding='utf-8-sig')
            elif file_path.endswith('.xlsx'):
                df.to_excel(file_path, index=False)
            else:
                return False
            
            return True
        except Exception as e:
            print(f"导出失败: {e}")
            return False
    
    @staticmethod
    def export_repair_records(db: Session, file_path: str) -> bool:
        """导出维修记录到CSV或Excel文件"""
        try:
            # 查询所有维修记录
            records = db.query(RepairRecord).all()
            
            # 准备数据
            data = []
            for record in records:
                data.append({
                    "id": record.id,
                    "defective_item_id": record.defective_item_id,
                    "repair_date": record.repair_date.strftime("%Y-%m-%d"),
                    "repairer": record.repairer,
                    "repair_method": record.repair_method,
                    "repair_duration": record.repair_duration,
                    "repair_cost": record.repair_cost,
                    "repair_result": record.repair_result,
                    "notes": record.notes,
                    "created_at": record.created_at.strftime("%Y-%m-%d %H:%M:%S")
                })
            
            # 创建DataFrame
            df = pd.DataFrame(data)
            
            # 根据文件扩展名导出
            if file_path.endswith('.csv'):
                df.to_csv(file_path, index=False, encoding='utf-8-sig')
            elif file_path.endswith('.xlsx'):
                df.to_excel(file_path, index=False)
            else:
                return False
            
            return True
        except Exception as e:
            print(f"导出失败: {e}")
            return False
    
    @staticmethod
    def import_defective_items(db: Session, file_path: str) -> Dict[str, Any]:
        """从CSV或Excel文件导入不良品记录"""
        try:
            # 读取文件
            if file_path.endswith('.csv'):
                df = pd.read_csv(file_path)
            elif file_path.endswith('.xlsx'):
                df = pd.read_excel(file_path)
            else:
                return {"success": False, "message": "不支持的文件格式"}
            
            # 验证必要字段
            required_fields = ['item_code', 'item_name', 'quantity', 'defect_date', 'defect_location', 'reported_by']
            if not all(field in df.columns for field in required_fields):
                return {"success": False, "message": f"缺少必要字段: {', '.join(required_fields)}"}
            
            # 导入数据
            success_count = 0
            error_count = 0
            errors = []
            
            for _, row in df.iterrows():
                try:
                    # 转换日期
                    defect_date = pd.to_datetime(row['defect_date']).date()
                    
                    # 创建不良品记录
                    DataService.add_defective_item(
                        db=db,
                        item_code=str(row['item_code']),
                        item_name=str(row['item_name']),
                        quantity=int(row['quantity']),
                        defect_date=defect_date,
                        defect_location=str(row['defect_location']),
                        reported_by=str(row['reported_by']),
                        description=str(row.get('description', '')) if pd.notna(row.get('description')) else None,
                        status=str(row.get('status', '待维修')) if pd.notna(row.get('status')) else '待维修'
                    )
                    success_count += 1
                except Exception as e:
                    error_count += 1
                    errors.append(f"第 {_+2} 行: {str(e)}")
            
            return {
                "success": True,
                "success_count": success_count,
                "error_count": error_count,
                "errors": errors
            }
        except Exception as e:
            return {"success": False, "message": f"导入失败: {str(e)}"}
    
    @staticmethod
    def import_repair_records(db: Session, file_path: str) -> Dict[str, Any]:
        """从CSV或Excel文件导入维修记录"""
        try:
            # 读取文件
            if file_path.endswith('.csv'):
                df = pd.read_csv(file_path)
            elif file_path.endswith('.xlsx'):
                df = pd.read_excel(file_path)
            else:
                return {"success": False, "message": "不支持的文件格式"}
            
            # 验证必要字段
            required_fields = ['defective_item_id', 'repair_date', 'repairer', 'repair_method', 'repair_duration', 'repair_cost', 'repair_result']
            if not all(field in df.columns for field in required_fields):
                return {"success": False, "message": f"缺少必要字段: {', '.join(required_fields)}"}
            
            # 导入数据
            success_count = 0
            error_count = 0
            errors = []
            
            for _, row in df.iterrows():
                try:
                    # 转换日期
                    repair_date = pd.to_datetime(row['repair_date']).date()
                    
                    # 创建维修记录
                    DataService.add_repair_record(
                        db=db,
                        defective_item_id=int(row['defective_item_id']),
                        repair_date=repair_date,
                        repairer=str(row['repairer']),
                        repair_method=str(row['repair_method']),
                        repair_duration=int(row['repair_duration']),
                        repair_cost=float(row['repair_cost']),
                        repair_result=str(row['repair_result']),
                        notes=str(row.get('notes', '')) if pd.notna(row.get('notes')) else None
                    )
                    success_count += 1
                except Exception as e:
                    error_count += 1
                    errors.append(f"第 {_+2} 行: {str(e)}")
            
            return {
                "success": True,
                "success_count": success_count,
                "error_count": error_count,
                "errors": errors
            }
        except Exception as e:
            return {"success": False, "message": f"导入失败: {str(e)}"}
