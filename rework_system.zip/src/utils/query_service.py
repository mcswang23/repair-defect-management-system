# 数据查询服务

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_
from datetime import date
from typing import List, Optional, Dict, Any

from src.models.models import DefectiveItem, RepairRecord, CauseAnalysis, Statistics

class QueryService:
    """数据查询服务类"""
    
    @staticmethod
    def get_defective_items(db: Session, item_code: Optional[str] = None, 
                          item_name: Optional[str] = None, 
                          status: Optional[str] = None, 
                          start_date: Optional[date] = None, 
                          end_date: Optional[date] = None, 
                          page: int = 1, page_size: int = 20) -> Dict[str, Any]:
        """查询不良品记录"""
        query = db.query(DefectiveItem)
        
        # 应用筛选条件
        if item_code:
            query = query.filter(DefectiveItem.item_code.ilike(f"%{item_code}%"))
        if item_name:
            query = query.filter(DefectiveItem.item_name.ilike(f"%{item_name}%"))
        if status:
            query = query.filter(DefectiveItem.status == status)
        if start_date:
            query = query.filter(DefectiveItem.defect_date >= start_date)
        if end_date:
            query = query.filter(DefectiveItem.defect_date <= end_date)
        
        # 计算总数
        total = query.count()
        
        # 分页
        offset = (page - 1) * page_size
        items = query.offset(offset).limit(page_size).all()
        
        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "items": items
        }
    
    @staticmethod
    def get_repair_records(db: Session, defective_item_id: Optional[int] = None, 
                          repairer: Optional[str] = None, 
                          start_date: Optional[date] = None, 
                          end_date: Optional[date] = None, 
                          page: int = 1, page_size: int = 20) -> Dict[str, Any]:
        """查询维修记录"""
        query = db.query(RepairRecord)
        
        # 应用筛选条件
        if defective_item_id:
            query = query.filter(RepairRecord.defective_item_id == defective_item_id)
        if repairer:
            query = query.filter(RepairRecord.repairer.ilike(f"%{repairer}%"))
        if start_date:
            query = query.filter(RepairRecord.repair_date >= start_date)
        if end_date:
            query = query.filter(RepairRecord.repair_date <= end_date)
        
        # 计算总数
        total = query.count()
        
        # 分页
        offset = (page - 1) * page_size
        records = query.offset(offset).limit(page_size).all()
        
        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "items": records
        }
    
    @staticmethod
    def get_cause_analyses(db: Session, defective_item_id: Optional[int] = None, 
                          analyst: Optional[str] = None, 
                          start_date: Optional[date] = None, 
                          end_date: Optional[date] = None) -> List[CauseAnalysis]:
        """查询原因分析"""
        query = db.query(CauseAnalysis)
        
        # 应用筛选条件
        if defective_item_id:
            query = query.filter(CauseAnalysis.defective_item_id == defective_item_id)
        if analyst:
            query = query.filter(CauseAnalysis.analyst.ilike(f"%{analyst}%"))
        if start_date:
            query = query.filter(CauseAnalysis.analysis_date >= start_date)
        if end_date:
            query = query.filter(CauseAnalysis.analysis_date <= end_date)
        
        return query.all()
    
    @staticmethod
    def get_statistics(db: Session, start_date: Optional[date] = None, 
                      end_date: Optional[date] = None) -> List[Statistics]:
        """查询统计汇总"""
        query = db.query(Statistics)
        
        # 应用筛选条件
        if start_date:
            query = query.filter(Statistics.period_start >= start_date)
        if end_date:
            query = query.filter(Statistics.period_end <= end_date)
        
        return query.order_by(Statistics.period_start.desc()).all()
    
    @staticmethod
    def get_defective_item_by_id(db: Session, item_id: int) -> Optional[DefectiveItem]:
        """根据ID获取不良品记录"""
        return db.query(DefectiveItem).filter(DefectiveItem.id == item_id).first()
    
    @staticmethod
    def get_repair_record_by_id(db: Session, record_id: int) -> Optional[RepairRecord]:
        """根据ID获取维修记录"""
        return db.query(RepairRecord).filter(RepairRecord.id == record_id).first()
    
    @staticmethod
    def get_cause_analysis_by_id(db: Session, analysis_id: int) -> Optional[CauseAnalysis]:
        """根据ID获取原因分析"""
        return db.query(CauseAnalysis).filter(CauseAnalysis.id == analysis_id).first()
    
    @staticmethod
    def get_statistics_by_id(db: Session, stats_id: int) -> Optional[Statistics]:
        """根据ID获取统计汇总"""
        return db.query(Statistics).filter(Statistics.id == stats_id).first()
