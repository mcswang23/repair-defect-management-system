# 命令行界面

import click
from datetime import date
from src.models.db import SessionLocal
from src.utils.data_service import DataService
from src.utils.query_service import QueryService
from src.utils.analysis_service import AnalysisService

@click.group()
def cli():
    """维修不良品统计系统命令行工具"""
    pass

# 不良品记录相关命令
@cli.group()
def defective():
    """不良品记录管理"""
    pass

@defective.command()
@click.option('--item-code', required=True, help='产品编码')
@click.option('--item-name', required=True, help='产品名称')
@click.option('--quantity', required=True, type=int, help='不良品数量')
@click.option('--defect-date', required=True, type=date.fromisoformat, help='发现日期 (YYYY-MM-DD)')
@click.option('--defect-location', required=True, help='发现位置')
@click.option('--reported-by', required=True, help='报告人')
@click.option('--description', help='不良描述')
@click.option('--status', default='待维修', help='状态 (待维修/维修中/已维修/报废)')
def add(item_code, item_name, quantity, defect_date, defect_location, reported_by, description, status):
    """添加不良品记录"""
    db = SessionLocal()
    try:
        item = DataService.add_defective_item(
            db=db,
            item_code=item_code,
            item_name=item_name,
            quantity=quantity,
            defect_date=defect_date,
            defect_location=defect_location,
            reported_by=reported_by,
            description=description,
            status=status
        )
        click.echo(f"不良品记录添加成功，ID: {item.id}")
    finally:
        db.close()

@defective.command()
@click.option('--id', required=True, type=int, help='不良品记录ID')
@click.option('--item-code', help='产品编码')
@click.option('--item-name', help='产品名称')
@click.option('--quantity', type=int, help='不良品数量')
@click.option('--defect-date', type=date.fromisoformat, help='发现日期 (YYYY-MM-DD)')
@click.option('--defect-location', help='发现位置')
@click.option('--reported-by', help='报告人')
@click.option('--description', help='不良描述')
@click.option('--status', help='状态 (待维修/维修中/已维修/报废)')
def update(id, **kwargs):
    """更新不良品记录"""
    db = SessionLocal()
    try:
        # 过滤掉None值
        update_data = {k: v for k, v in kwargs.items() if v is not None}
        if update_data:
            item = DataService.update_defective_item(db=db, item_id=id, **update_data)
            if item:
                click.echo(f"不良品记录更新成功，ID: {item.id}")
            else:
                click.echo(f"不良品记录不存在，ID: {id}")
        else:
            click.echo("没有提供更新数据")
    finally:
        db.close()

@defective.command()
@click.option('--id', required=True, type=int, help='不良品记录ID')
def delete(id):
    """删除不良品记录"""
    db = SessionLocal()
    try:
        success = DataService.delete_defective_item(db=db, item_id=id)
        if success:
            click.echo(f"不良品记录删除成功，ID: {id}")
        else:
            click.echo(f"不良品记录不存在，ID: {id}")
    finally:
        db.close()

@defective.command()
@click.option('--item-code', help='产品编码')
@click.option('--item-name', help='产品名称')
@click.option('--status', help='状态 (待维修/维修中/已维修/报废)')
@click.option('--start-date', type=date.fromisoformat, help='开始日期 (YYYY-MM-DD)')
@click.option('--end-date', type=date.fromisoformat, help='结束日期 (YYYY-MM-DD)')
@click.option('--page', default=1, type=int, help='页码')
@click.option('--page-size', default=20, type=int, help='每页数量')
def list(item_code, item_name, status, start_date, end_date, page, page_size):
    """查询不良品记录"""
    db = SessionLocal()
    try:
        result = QueryService.get_defective_items(
            db=db,
            item_code=item_code,
            item_name=item_name,
            status=status,
            start_date=start_date,
            end_date=end_date,
            page=page,
            page_size=page_size
        )
        click.echo(f"共 {result['total']} 条记录，第 {result['page']} 页")
        for item in result['items']:
            click.echo(f"ID: {item.id}, 产品: {item.item_code} - {item.item_name}, 数量: {item.quantity}, 日期: {item.defect_date}, 状态: {item.status}")
    finally:
        db.close()

# 维修记录相关命令
@cli.group()
def repair():
    """维修记录管理"""
    pass

@repair.command()
@click.option('--defective-item-id', required=True, type=int, help='不良品记录ID')
@click.option('--repair-date', required=True, type=date.fromisoformat, help='维修日期 (YYYY-MM-DD)')
@click.option('--repairer', required=True, help='维修人员')
@click.option('--repair-method', required=True, help='维修方法')
@click.option('--repair-duration', required=True, type=int, help='维修时长(分钟)')
@click.option('--repair-cost', required=True, type=float, help='维修成本')
@click.option('--repair-result', required=True, help='维修结果 (成功/失败/部分成功)')
@click.option('--notes', help='维修备注')
def add(defective_item_id, repair_date, repairer, repair_method, repair_duration, repair_cost, repair_result, notes):
    """添加维修记录"""
    db = SessionLocal()
    try:
        record = DataService.add_repair_record(
            db=db,
            defective_item_id=defective_item_id,
            repair_date=repair_date,
            repairer=repairer,
            repair_method=repair_method,
            repair_duration=repair_duration,
            repair_cost=repair_cost,
            repair_result=repair_result,
            notes=notes
        )
        click.echo(f"维修记录添加成功，ID: {record.id}")
    finally:
        db.close()

@repair.command()
@click.option('--defective-item-id', type=int, help='不良品记录ID')
@click.option('--repairer', help='维修人员')
@click.option('--start-date', type=date.fromisoformat, help='开始日期 (YYYY-MM-DD)')
@click.option('--end-date', type=date.fromisoformat, help='结束日期 (YYYY-MM-DD)')
@click.option('--page', default=1, type=int, help='页码')
@click.option('--page-size', default=20, type=int, help='每页数量')
def list(defective_item_id, repairer, start_date, end_date, page, page_size):
    """查询维修记录"""
    db = SessionLocal()
    try:
        result = QueryService.get_repair_records(
            db=db,
            defective_item_id=defective_item_id,
            repairer=repairer,
            start_date=start_date,
            end_date=end_date,
            page=page,
            page_size=page_size
        )
        click.echo(f"共 {result['total']} 条记录，第 {result['page']} 页")
        for record in result['items']:
            click.echo(f"ID: {record.id}, 不良品ID: {record.defective_item_id}, 日期: {record.repair_date}, 维修人员: {record.repairer}, 结果: {record.repair_result}")
    finally:
        db.close()

# 原因分析相关命令
@cli.group()
def analysis():
    """原因分析管理"""
    pass

@analysis.command()
@click.option('--defective-item-id', required=True, type=int, help='不良品记录ID')
@click.option('--analysis-date', required=True, type=date.fromisoformat, help='分析日期 (YYYY-MM-DD)')
@click.option('--analyst', required=True, help='分析人员')
@click.option('--root-cause', required=True, help='根本原因')
@click.option('--contributing-factors', help='影响因素')
@click.option('--preventive-measures', help='预防措施')
def add(defective_item_id, analysis_date, analyst, root_cause, contributing_factors, preventive_measures):
    """添加原因分析"""
    db = SessionLocal()
    try:
        analysis = DataService.add_cause_analysis(
            db=db,
            defective_item_id=defective_item_id,
            analysis_date=analysis_date,
            analyst=analyst,
            root_cause=root_cause,
            contributing_factors=contributing_factors,
            preventive_measures=preventive_measures
        )
        click.echo(f"原因分析添加成功，ID: {analysis.id}")
    finally:
        db.close()

# 统计分析相关命令
@cli.group()
def stats():
    """统计分析"""
    pass

@stats.command()
@click.option('--start-date', required=True, type=date.fromisoformat, help='开始日期 (YYYY-MM-DD)')
@click.option('--end-date', required=True, type=date.fromisoformat, help='结束日期 (YYYY-MM-DD)')
def analyze(start_date, end_date):
    """分析指定时间段的不良品情况"""
    db = SessionLocal()
    try:
        result = AnalysisService.analyze_period(db=db, start_date=start_date, end_date=end_date)
        click.echo("分析结果:")
        click.echo(f"统计ID: {result['statistics'].id}")
        click.echo(f"时间段: {start_date} 至 {end_date}")
        click.echo(f"不良品总数: {result['details']['total_defective']}")
        click.echo(f"不良品总数量: {result['details']['total_quantity']}")
        click.echo(f"已维修数量: {result['details']['total_repaired']}")
        click.echo(f"维修率: {result['details']['repair_rate']:.2f}%")
        click.echo(f"总维修成本: {result['details']['total_repair_cost']:.2f}")
        click.echo(f"平均维修时长: {result['details']['average_repair_time']:.2f} 分钟")
        click.echo(f"最常见原因: {result['details']['most_common_cause']}")
        click.echo("状态分布:")
        for status, count in result['details']['status_count'].items():
            click.echo(f"  {status}: {count}")
    finally:
        db.close()

@stats.command()
@click.option('--months', default=6, type=int, help='分析最近几个月的数据')
def trend(months):
    """获取趋势分析数据"""
    db = SessionLocal()
    try:
        data = AnalysisService.get_trend_analysis(db=db, months=months)
        click.echo(f"最近 {months} 个月的趋势分析:")
        for item in data:
            click.echo(f"月份: {item['month']}")
            click.echo(f"  不良品数量: {item['data']['total_defective']}")
            click.echo(f"  已维修数量: {item['data']['total_repaired']}")
            click.echo(f"  维修率: {item['data']['repair_rate']:.2f}%")
            click.echo(f"  总维修成本: {item['data']['total_repair_cost']:.2f}")
    finally:
        db.close()

@stats.command()
@click.option('--months', default=3, type=int, help='分析最近几个月的维修效率')
def efficiency(months):
    """分析维修效率"""
    db = SessionLocal()
    try:
        stats = AnalysisService.get_repair_efficiency_analysis(db=db, months=months)
        click.echo(f"最近 {months} 个月的维修效率分析:")
        for repairer, data in stats.items():
            click.echo(f"维修人员: {repairer}")
            click.echo(f"  维修次数: {data['total_repairs']}")
            click.echo(f"  成功率: {data['success_rate']:.2f}%")
            click.echo(f"  平均维修时长: {data['average_duration']:.2f} 分钟")
            click.echo(f"  平均维修成本: {data['average_cost']:.2f}")
    finally:
        db.close()

# 数据库初始化命令
@cli.command()
def init_db():
    """初始化数据库"""
    from src.models.init_db import init_db
    init_db()

if __name__ == '__main__':
    cli()
