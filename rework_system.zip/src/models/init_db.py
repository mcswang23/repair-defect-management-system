# 数据库初始化模块

import sys
import os

# 添加项目根目录到Python路径
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from src.models.db import engine, Base
from src.models.models import DefectiveItem, User, PcbMaterialMapping, NgCode

def init_db():
    """初始化数据库，创建所有表"""
    Base.metadata.create_all(bind=engine)
    print("数据库初始化完成，表结构已创建")

if __name__ == "__main__":
    init_db()
