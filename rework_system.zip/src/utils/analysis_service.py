# 统计分析服务

from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import date, timedelta
from typing import Dict, Any, List, Tuple

from src.models.models import DefectiveItem, RepairRecord, CauseAnalysis, Statistics
from src.utils.data_service import DataService

class AnalysisService:
    """统计分析服务类"""
    
    @staticmethod
    def analyze_period(db: Session, start_date: date, end_date: date) -> Dict[str, Any]:
        """分析指定时间段的不良品情况"""
        # 查询时间段内的不良品记录
        defective_items = db.query(DefectiveItem).filter(
            DefectiveItem.defect_date >= start_date,
            DefectiveItem.defect_date <= end_date
        ).all()
        
        # 计算基本统计数据
        total_defective = len(defective_items)
        total_quantity = sum(item.quantity for item in defective_items)
        
        # 按状态统计
        status_count = {}
        for item in defective_items:
            status_count[item.status] = status_count.get(item.status, 0) + 1
        
        # 按产品编码统计
        product_count = {}
        for item in defective_items:
            product_count[item.item_code] = product_count.get(item.item_code, 0) + item.quantity
        
        # 按位置统计
        location_count = {}
        for item in defective_items:
            location_count[item.defect_location] = location_count.get(item.defect_location, 0) + 1
        
        # 分析维修情况
        repair_records = db.query(RepairRecord).join(DefectiveItem).filter(
            DefectiveItem.defect_date >= start_date,
            DefectiveItem.defect_date <= end_date
        ).all()
        
        total_repaired = len(repair_records)
        total_repair_cost = sum(record.repair_cost for record in repair_records)
        total_repair_duration = sum(record.repair_duration for record in repair_records)
        average_repair_time = total_repair_duration / total_repaired if total_repaired > 0 else 0
        
        # 计算维修率
        repair_rate = (total_repaired / total_defective * 100) if total_defective > 0 else 0
        
        # 分析原因
        cause_analyses = db.query(CauseAnalysis).join(DefectiveItem).filter(
            DefectiveItem.defect_date >= start_date,
            DefectiveItem.defect_date <= end_date
        ).all()
        
        # 统计最常见的原因
        cause_count = {}
        for analysis in cause_analyses:
            cause_count[analysis.root_cause] = cause_count.get(analysis.root_cause, 0) + 1
        
        most_common_cause = max(cause_count, key=cause_count.get) if cause_count else None
        
        # 保存统计结果
        stats = DataService.add_statistics(
            db=db,
            period_start=start_date,
            period_end=end_date,
            total_defective=total_defective,
            total_repaired=total_repaired,
            total_scrapped=status_count.get("报废", 0),
            repair_rate=repair_rate,
            average_repair_time=average_repair_time,
            total_repair_cost=total_repair_cost,
            most_common_cause=most_common_cause
        )
        
        return {
            "statistics": stats,
            "details": {
                "total_defective": total_defective,
                "total_quantity": total_quantity,
                "status_count": status_count,
                "product_count": product_count,
                "location_count": location_count,
                "total_repaired": total_repaired,
                "total_repair_cost": total_repair_cost,
                "average_repair_time": average_repair_time,
                "repair_rate": repair_rate,
                "most_common_cause": most_common_cause
            }
        }
    
    @staticmethod
    def get_trend_analysis(db: Session, months: int = 6) -> List[Dict[str, Any]]:
        """获取趋势分析数据"""
        end_date = date.today()
        start_date = end_date - timedelta(days=months*30)
        
        # 按月份分组统计
        monthly_data = []
        current_date = start_date
        
        while current_date <= end_date:
            month_end = date(current_date.year, current_date.month, 28) + timedelta(days=4)
            month_end = month_end.replace(day=1) - timedelta(days=1)
            month_end = min(month_end, end_date)
            
            # 统计当月数据
            month_result = AnalysisService.analyze_period(db, current_date, month_end)
            monthly_data.append({
                "month": current_date.strftime("%Y-%m"),
                "data": month_result["details"]
            })
            
            # 移动到下一个月
            current_date = date(current_date.year, current_date.month, 1) + timedelta(days=32)
            current_date = date(current_date.year, current_date.month, 1)
        
        return monthly_data
    
    @staticmethod
    def get_repair_efficiency_analysis(db: Session, months: int = 3) -> Dict[str, Any]:
        """分析维修效率"""
        end_date = date.today()
        start_date = end_date - timedelta(days=months*30)
        
        # 查询维修记录
        repair_records = db.query(RepairRecord).filter(
            RepairRecord.repair_date >= start_date,
            RepairRecord.repair_date <= end_date
        ).all()
        
        # 按维修人员统计
        repairer_stats = {}
        for record in repair_records:
            if record.repairer not in repairer_stats:
                repairer_stats[record.repairer] = {
                    "total_repairs": 0,
                    "total_duration": 0,
                    "total_cost": 0,
                    "success_count": 0
                }
            
            repairer_stats[record.repairer]["total_repairs"] += 1
            repairer_stats[record.repairer]["total_duration"] += record.repair_duration
            repairer_stats[record.repairer]["total_cost"] += record.repair_cost
            if record.repair_result == "成功":
                repairer_stats[record.repairer]["success_count"] += 1
        
        # 计算效率指标
        for repairer, stats in repairer_stats.items():
            stats["average_duration"] = stats["total_duration"] / stats["total_repairs"] if stats["total_repairs"] > 0 else 0
            stats["average_cost"] = stats["total_cost"] / stats["total_repairs"] if stats["total_repairs"] > 0 else 0
            stats["success_rate"] = stats["success_count"] / stats["total_repairs"] * 100 if stats["total_repairs"] > 0 else 0
        
        return repairer_stats
    
    @staticmethod
    def get_product_quality_analysis(db: Session, months: int = 6) -> Dict[str, Any]:
        """分析产品质量"""
        end_date = date.today()
        start_date = end_date - timedelta(days=months*30)
        
        # 查询不良品记录
        defective_items = db.query(DefectiveItem).filter(
            DefectiveItem.defect_date >= start_date,
            DefectiveItem.defect_date <= end_date
        ).all()
        
        # 按产品编码统计
        product_stats = {}
        for item in defective_items:
            if item.item_code not in product_stats:
                product_stats[item.item_code] = {
                    "name": item.item_name,
                    "total_defective": 0,
                    "total_quantity": 0,
                    "repair_count": 0,
                    "scrap_count": 0
                }
            
            product_stats[item.item_code]["total_defective"] += 1
            product_stats[item.item_code]["total_quantity"] += item.quantity
            if item.status == "已维修":
                product_stats[item.item_code]["repair_count"] += 1
            elif item.status == "报废":
                product_stats[item.item_code]["scrap_count"] += 1
        
        # 计算产品的维修率和报废率
        for product, stats in product_stats.items():
            stats["repair_rate"] = stats["repair_count"] / stats["total_defective"] * 100 if stats["total_defective"] > 0 else 0
            stats["scrap_rate"] = stats["scrap_count"] / stats["total_defective"] * 100 if stats["total_defective"] > 0 else 0
        
        # 按不良品数量排序
        sorted_products = sorted(product_stats.items(), key=lambda x: x[1]["total_defective"], reverse=True)
        
        return {
            "total_products": len(product_stats),
            "top_defective_products": sorted_products[:5],
            "product_stats": product_stats
        }
    
    @staticmethod
    def get_cost_analysis(db: Session, months: int = 6) -> Dict[str, Any]:
        """分析维修成本"""
        end_date = date.today()
        start_date = end_date - timedelta(days=months*30)
        
        # 查询维修记录
        repair_records = db.query(RepairRecord).join(DefectiveItem).filter(
            DefectiveItem.defect_date >= start_date,
            DefectiveItem.defect_date <= end_date
        ).all()
        
        # 按月份统计成本
        monthly_costs = {}
        for record in repair_records:
            month = record.repair_date.strftime("%Y-%m")
            if month not in monthly_costs:
                monthly_costs[month] = {
                    "total_cost": 0,
                    "total_repairs": 0,
                    "average_cost": 0
                }
            monthly_costs[month]["total_cost"] += record.repair_cost
            monthly_costs[month]["total_repairs"] += 1
        
        # 计算平均成本
        for month, stats in monthly_costs.items():
            stats["average_cost"] = stats["total_cost"] / stats["total_repairs"] if stats["total_repairs"] > 0 else 0
        
        # 按月份排序
        sorted_months = sorted(monthly_costs.items(), key=lambda x: x[0])
        
        # 计算总成本和平均成本
        total_cost = sum(stats["total_cost"] for stats in monthly_costs.values())
        total_repairs = sum(stats["total_repairs"] for stats in monthly_costs.values())
        overall_average_cost = total_cost / total_repairs if total_repairs > 0 else 0
        
        return {
            "total_cost": total_cost,
            "total_repairs": total_repairs,
            "overall_average_cost": overall_average_cost,
            "monthly_costs": sorted_months
        }
    
    @staticmethod
    def get_location_analysis(db: Session, months: int = 3) -> Dict[str, Any]:
        """分析不良品位置分布"""
        end_date = date.today()
        start_date = end_date - timedelta(days=months*30)
        
        # 查询不良品记录
        defective_items = db.query(DefectiveItem).filter(
            DefectiveItem.defect_date >= start_date,
            DefectiveItem.defect_date <= end_date
        ).all()
        
        # 按位置统计
        location_stats = {}
        for item in defective_items:
            if item.defect_location not in location_stats:
                location_stats[item.defect_location] = {
                    "total_defective": 0,
                    "total_quantity": 0,
                    "product_codes": set()
                }
            location_stats[item.defect_location]["total_defective"] += 1
            location_stats[item.defect_location]["total_quantity"] += item.quantity
            location_stats[item.defect_location]["product_codes"].add(item.item_code)
        
        # 计算每个位置的产品种类数
        for location, stats in location_stats.items():
            stats["product_count"] = len(stats["product_codes"])
            del stats["product_codes"]  # 删除临时数据
        
        # 按不良品数量排序
        sorted_locations = sorted(location_stats.items(), key=lambda x: x[1]["total_defective"], reverse=True)
        
        return {
            "total_locations": len(location_stats),
            "top_defective_locations": sorted_locations[:5],
            "location_stats": location_stats
        }
