# 数据库模型定义

from sqlalchemy import Column, Integer, String, Text, Date, DateTime, ForeignKey, Numeric
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from src.models.db import Base

class DefectiveItem(Base):
    """不良品记录表"""
    __tablename__ = "defective_items"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    project = Column(String(100), nullable=False, index=True)  # 项目
    sfc = Column(String(50), nullable=False, index=True)  # 条码
    station = Column(String(100), nullable=False)  # 站别
    repair_time = Column(DateTime(timezone=True), nullable=False)  # 送修时间
    mes_defect_info = Column(Text)  # MES不良信息
    analysis_result = Column(Text)  # 分析结果
    material_code = Column(String(50), nullable=False)  # 料号
    failure_code = Column(String(100))  # Failure Code
    attached_pcba_sfc = Column(String(50))  # 附带PCBA SFC
    repairer = Column(String(50), nullable=False, index=True)  # 维修人员
    analysis_status = Column(String(20), nullable=False, index=True)  # 是否完成分析
    repair_complete_time = Column(DateTime(timezone=True))  # 维修完成时间
    return_to_line_time = Column(DateTime(timezone=True))  # 返回产线时间
    repair_count = Column(Integer, nullable=False, default=1)  # 维修次数
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

class User(Base):
    """用户表"""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(50), nullable=False, unique=True, index=True)
    password = Column(String(100), nullable=False)
    role = Column(String(20), nullable=False)  # 角色：repairer, engineer
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class PcbMaterialMapping(Base):
    """PCBA料号映射表"""
    __tablename__ = "pcb_material_mappings"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    pcb_code = Column(String(50), nullable=False, unique=True, index=True)
    project_name = Column(String(100), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class NgCode(Base):
    """NG Code字典表"""
    __tablename__ = "ng_codes"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    code = Column(String(50), nullable=False, unique=True, index=True)
    description = Column(String(100), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Station(Base):
    """站别表"""
    __tablename__ = "stations"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    station_name = Column(String(100), nullable=False, unique=True, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
