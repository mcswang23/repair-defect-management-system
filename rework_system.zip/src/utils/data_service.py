# 数据管理服务

from sqlalchemy.orm import Session
from datetime import date

from src.models.models import DefectiveItem, RepairRecord, CauseAnalysis, Statistics

class DataService:
    """数据管理服务类"""
    
    @staticmethod
    def add_defective_item(db: Session, item_code: str, item_name: str, quantity: int, 
                          defect_date: date, defect_location: str, reported_by: str, 
                          description: str = None, status: str = "待维修") -> DefectiveItem:
        """添加不良品记录"""
        db_item = DefectiveItem(
            item_code=item_code,
            item_name=item_name,
            quantity=quantity,
            defect_date=defect_date,
            defect_location=defect_location,
            reported_by=reported_by,
            description=description,
            status=status
        )
        db.add(db_item)
        db.commit()
        db.refresh(db_item)
        return db_item
    
    @staticmethod
    def update_defective_item(db: Session, item_id: int, **kwargs) -> DefectiveItem:
        """更新不良品记录"""
        db_item = db.query(DefectiveItem).filter(DefectiveItem.id == item_id).first()
        if db_item:
            for key, value in kwargs.items():
                if hasattr(db_item, key):
                    setattr(db_item, key, value)
            db.commit()
            db.refresh(db_item)
        return db_item
    
    @staticmethod
    def delete_defective_item(db: Session, item_id: int) -> bool:
        """删除不良品记录"""
        db_item = db.query(DefectiveItem).filter(DefectiveItem.id == item_id).first()
        if db_item:
            db.delete(db_item)
            db.commit()
            return True
        return False
    
    @staticmethod
    def add_repair_record(db: Session, defective_item_id: int, repair_date: date, 
                         repairer: str, repair_method: str, repair_duration: int, 
                         repair_cost: float, repair_result: str, notes: str = None) -> RepairRecord:
        """添加维修记录"""
        db_record = RepairRecord(
            defective_item_id=defective_item_id,
            repair_date=repair_date,
            repairer=repairer,
            repair_method=repair_method,
            repair_duration=repair_duration,
            repair_cost=repair_cost,
            repair_result=repair_result,
            notes=notes
        )
        db.add(db_record)
        db.commit()
        db.refresh(db_record)
        return db_record
    
    @staticmethod
    def add_cause_analysis(db: Session, defective_item_id: int, analysis_date: date, 
                          analyst: str, root_cause: str, contributing_factors: str = None, 
                          preventive_measures: str = None) -> CauseAnalysis:
        """添加原因分析"""
        db_analysis = CauseAnalysis(
            defective_item_id=defective_item_id,
            analysis_date=analysis_date,
            analyst=analyst,
            root_cause=root_cause,
            contributing_factors=contributing_factors,
            preventive_measures=preventive_measures
        )
        db.add(db_analysis)
        db.commit()
        db.refresh(db_analysis)
        return db_analysis
    
    @staticmethod
    def add_statistics(db: Session, period_start: date, period_end: date, total_defective: int, 
                      total_repaired: int, total_scrapped: int, repair_rate: float, 
                      average_repair_time: float, total_repair_cost: float, 
                      most_common_cause: str = None) -> Statistics:
        """添加统计汇总"""
        db_statistics = Statistics(
            period_start=period_start,
            period_end=period_end,
            total_defective=total_defective,
            total_repaired=total_repaired,
            total_scrapped=total_scrapped,
            repair_rate=repair_rate,
            average_repair_time=average_repair_time,
            total_repair_cost=total_repair_cost,
            most_common_cause=most_common_cause
        )
        db.add(db_statistics)
        db.commit()
        db.refresh(db_statistics)
        return db_statistics
