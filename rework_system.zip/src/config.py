# 配置文件

import os
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 数据库配置 - 使用SQLite
import os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATABASE_URL = f'sqlite:///{os.path.join(BASE_DIR, "rework_system.db")}'

# 应用配置
APP_NAME = os.getenv('APP_NAME', '维修不良品管理系统')
APP_VERSION = os.getenv('APP_VERSION', '1.0.0')
SECRET_KEY = os.getenv('SECRET_KEY', 'your_secret_key')

# 日志配置
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')

# 其他配置
DEFAULT_PAGE_SIZE = 20
MAX_PAGE_SIZE = 100

