# Web界面应用

import sys
import os
import json
from datetime import datetime, timedelta

# 添加项目根目录到Python路径
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from src.models.db import engine, Base
from src.models.models import DefectiveItem, User, PcbMaterialMapping, NgCode, Station
from src.config import APP_NAME, APP_VERSION, SECRET_KEY, DATABASE_URL

# 创建Flask应用
app = Flask(__name__)
app.config['SECRET_KEY'] = SECRET_KEY
app.config['SQLALCHEMY_DATABASE_URI'] = DATABASE_URL
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_POOL_SIZE'] = 10
app.config['SQLALCHEMY_MAX_OVERFLOW'] = 20
app.config['SQLALCHEMY_POOL_TIMEOUT'] = 30

# 初始化数据库
db = SQLAlchemy(app)

# 确保表结构存在
Base.metadata.create_all(bind=engine)

# 主页
@app.route('/')
def index():
    return render_template('index.html', app_name=APP_NAME, app_version=APP_VERSION)

# 产品输入系统
@app.route('/input', methods=['GET', 'POST'])
def product_input():
    if request.method == 'POST':
        try:
            # 获取表单数据
            sfc = request.form['sfc']
            # 根据SFC提取PCBA料号（这里需要根据命名规则实现）
            pcb_code = extract_pcb_code(sfc)
            
            # 查询字典文件
            pcb_mapping = db.session.query(PcbMaterialMapping).filter_by(pcb_code=pcb_code).first()
            project = pcb_mapping.project_name if pcb_mapping else None
            
            # 查询MES（模拟实现）
            mes_data = query_mes(sfc)
            station = mes_data.get('station') if mes_data else None
            
            # 如果字典和MES查询不到，使用手动输入的值
            if not project:
                project = request.form['project']
            if not station:
                station = request.form['station']
            
            # 检查是否已经存在相同SFC的记录
            existing_item = db.session.query(DefectiveItem).filter_by(sfc=sfc).first()
            if existing_item:
                flash('该SFC已经存在，请不要重复输入！', 'danger')
                return redirect(url_for('product_input'))
            
            # 添加记录
            new_item = DefectiveItem(
                project=project,
                sfc=sfc,
                station=station,
                repair_time=datetime.now(),
                material_code=pcb_code,
                analysis_status='PENDING',
                repair_count=1
            )
            db.session.add(new_item)
            db.session.commit()
            
            flash('产品输入成功！', 'success')
            return redirect(url_for('index'))
        except Exception as e:
            flash(f'输入失败: {str(e)}', 'danger')
    
    # 获取所有项目名称供选择
    projects = db.session.query(PcbMaterialMapping.project_name).distinct().all()
    projects = [p[0] for p in projects]
    
    return render_template('input.html', projects=projects)

# 不良品分析处理
@app.route('/analysis', methods=['GET', 'POST'])
def defect_analysis():
    if request.method == 'POST':
        try:
            # 获取表单数据
            sfc = request.form['sfc']
            location = request.form['location']
            ng_code = request.form['ng_code']
            attached_pcba_sfc = request.form.get('attached_pcba_sfc', '')
            repairer = request.form['repairer']
            
            # 查找记录
            item = db.session.query(DefectiveItem).filter_by(sfc=sfc).first()
            if not item:
                flash('未找到该SFC的记录！', 'danger')
                return redirect(url_for('defect_analysis'))
            
            # 检查流程顺序
            if item.analysis_status != 'PENDING':
                flash('该记录已经分析过，请按照顺序处理！', 'danger')
                return redirect(url_for('defect_analysis'))
            
            # 查询MES不良信息（模拟实现）
            mes_data = query_mes(sfc)
            mes_defect_info = mes_data.get('defect_info', '') if mes_data else ''
            
            # 根据PCBA料号和Location查询BOM（模拟实现）
            component_number = query_bom(item.material_code, location)
            
            # 更新记录
            item.mes_defect_info = mes_defect_info
            item.analysis_result = component_number
            item.failure_code = ng_code
            item.attached_pcba_sfc = attached_pcba_sfc
            item.repairer = repairer
            item.analysis_status = 'DONE'
            item.repair_complete_time = datetime.now()
            db.session.commit()
            
            flash('不良品分析处理成功！', 'success')
            return redirect(url_for('index'))
        except Exception as e:
            flash(f'处理失败: {str(e)}', 'danger')
    
    # 获取所有NG Code
    ng_codes = db.session.query(NgCode).all()
    
    return render_template('analysis.html', ng_codes=ng_codes)

# 产品返回产线
@app.route('/return', methods=['GET', 'POST'])
def return_to_line():
    if request.method == 'POST':
        try:
            # 获取表单数据
            sfc = request.form['sfc']
            
            # 查找记录
            item = db.session.query(DefectiveItem).filter_by(sfc=sfc).first()
            if not item:
                flash('未找到该SFC的记录！', 'danger')
                return redirect(url_for('return_to_line'))
            
            # 检查流程顺序
            if item.analysis_status != 'DONE':
                flash('请先完成不良品分析处理！', 'danger')
                return redirect(url_for('return_to_line'))
            
            if item.return_to_line_time:
                flash('该产品已经返回产线！', 'danger')
                return redirect(url_for('return_to_line'))
            
            # 更新记录
            item.return_to_line_time = datetime.now()
            db.session.commit()
            
            flash('产品返回产线成功！', 'success')
            return redirect(url_for('index'))
        except Exception as e:
            flash(f'处理失败: {str(e)}', 'danger')
    
    return render_template('return.html')

# 报表系统
@app.route('/report', methods=['GET', 'POST'])
def report():
    if request.method == 'POST':
        try:
            # 获取查询参数
            project = request.form.get('project', '')
            start_date = request.form.get('start_date', '')
            end_date = request.form.get('end_date', '')
            sfc = request.form.get('sfc', '')
            repairer = request.form.get('repairer', '')
            
            # 构建查询
            query = db.session.query(DefectiveItem)
            
            if project:
                query = query.filter_by(project=project)
            if sfc:
                query = query.filter_by(sfc=sfc)
            if repairer:
                query = query.filter_by(repairer=repairer)
            if start_date:
                query = query.filter(DefectiveItem.repair_time >= datetime.fromisoformat(start_date))
            if end_date:
                query = query.filter(DefectiveItem.repair_time <= datetime.fromisoformat(end_date) + timedelta(days=1))
            
            # 执行查询
            items = query.all()
            
            # 导出报表（这里可以实现为Excel或CSV）
            # 暂时只显示在页面上
            return render_template('report_result.html', items=items)
        except Exception as e:
            flash(f'查询失败: {str(e)}', 'danger')
    
    # 获取所有项目和维修员
    projects = db.session.query(DefectiveItem.project).distinct().all()
    projects = [p[0] for p in projects]
    repairers = db.session.query(DefectiveItem.repairer).distinct().all()
    repairers = [r[0] for r in repairers if r[0]]
    
    return render_template('report.html', projects=projects, repairers=repairers)

# 工具函数：从SFC提取PCBA料号
def extract_pcb_code(sfc):
    # 根据命名规则提取PCBA料号
    # 这里需要根据实际的命名规则实现
    return sfc[:10]  # 示例实现

# 工具函数：查询MES
def query_mes(sfc):
    # 模拟查询MES
    # 实际应该调用MES API
    return {
        'station': 'Flash',
        'defect_info': ';; Denso_Bootloader_BLE'
    }

# 工具函数：查询BOM
def query_bom(pcb_code, location):
    # 模拟查询BOM
    # 实际应该读取C:\BOM目录下的文件
    return 'L7803'  # 示例实现

# 登录页面
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        try:
            username = request.form['username']
            password = request.form['password']
            
            # 查找用户
            user = db.session.query(User).filter_by(username=username).first()
            if not user or user.password != password:
                flash('用户名或密码错误！', 'danger')
                return redirect(url_for('login'))
            
            # 保存用户信息到会话
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role
            
            flash('登录成功！', 'success')
            return redirect(url_for('index'))
        except Exception as e:
            flash(f'登录失败: {str(e)}', 'danger')
    
    return render_template('login.html')

# 注册页面
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            username = request.form['username']
            password = request.form['password']
            role = request.form['role']
            
            # 检查用户名是否已存在
            existing_user = db.session.query(User).filter_by(username=username).first()
            if existing_user:
                flash('用户名已存在！', 'danger')
                return redirect(url_for('register'))
            
            # 创建新用户
            new_user = User(
                username=username,
                password=password,
                role=role
            )
            db.session.add(new_user)
            db.session.commit()
            
            flash('注册成功！请登录', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            flash(f'注册失败: {str(e)}', 'danger')
    
    return render_template('register.html')

# 登出
@app.route('/logout')
def logout():
    session.clear()
    flash('已登出！', 'success')
    return redirect(url_for('login'))

# 字典文件管理
@app.route('/dictionary')
def dictionary():
    # 检查用户权限
    if 'role' not in session or session['role'] != 'engineer':
        flash('只有工程师权限可以管理字典！', 'danger')
        return redirect(url_for('index'))
    
    # 获取所有PCBA料号映射、NG Code和站别
    pcb_mappings = db.session.query(PcbMaterialMapping).all()
    ng_codes = db.session.query(NgCode).all()
    stations = db.session.query(Station).all()
    
    return render_template('dictionary.html', pcb_mappings=pcb_mappings, ng_codes=ng_codes, stations=stations)

# 添加PCBA料号映射
@app.route('/add_pcb_mapping', methods=['POST'])
def add_pcb_mapping():
    if 'role' not in session or session['role'] != 'engineer':
        flash('只有工程师权限可以管理字典！', 'danger')
        return redirect(url_for('index'))
    
    try:
        pcb_code = request.form['pcb_code']
        project_name = request.form['project_name']
        
        # 检查是否已存在
        existing = db.session.query(PcbMaterialMapping).filter_by(pcb_code=pcb_code).first()
        if existing:
            flash('该PCBA料号已存在！', 'danger')
            return redirect(url_for('dictionary'))
        
        # 添加新映射
        new_mapping = PcbMaterialMapping(
            pcb_code=pcb_code,
            project_name=project_name
        )
        db.session.add(new_mapping)
        db.session.commit()
        
        flash('PCBA料号映射添加成功！', 'success')
    except Exception as e:
        flash(f'添加失败: {str(e)}', 'danger')
    
    return redirect(url_for('dictionary'))

# 删除PCBA料号映射
@app.route('/delete_pcb_mapping/<int:id>')
def delete_pcb_mapping(id):
    if 'role' not in session or session['role'] != 'engineer':
        flash('只有工程师权限可以管理字典！', 'danger')
        return redirect(url_for('index'))
    
    try:
        mapping = db.session.query(PcbMaterialMapping).get(id)
        if mapping:
            db.session.delete(mapping)
            db.session.commit()
            flash('PCBA料号映射删除成功！', 'success')
        else:
            flash('映射不存在！', 'danger')
    except Exception as e:
        flash(f'删除失败: {str(e)}', 'danger')
    
    return redirect(url_for('dictionary'))

# 添加NG Code
@app.route('/add_ng_code', methods=['POST'])
def add_ng_code():
    if 'role' not in session or session['role'] != 'engineer':
        flash('只有工程师权限可以管理字典！', 'danger')
        return redirect(url_for('index'))
    
    try:
        code = request.form['code']
        description = request.form['description']
        
        # 检查是否已存在
        existing = db.session.query(NgCode).filter_by(code=code).first()
        if existing:
            flash('该NG Code已存在！', 'danger')
            return redirect(url_for('dictionary'))
        
        # 添加新NG Code
        new_ng_code = NgCode(
            code=code,
            description=description
        )
        db.session.add(new_ng_code)
        db.session.commit()
        
        flash('NG Code添加成功！', 'success')
    except Exception as e:
        flash(f'添加失败: {str(e)}', 'danger')
    
    return redirect(url_for('dictionary'))

# 删除NG Code
@app.route('/delete_ng_code/<int:id>')
def delete_ng_code(id):
    if 'role' not in session or session['role'] != 'engineer':
        flash('只有工程师权限可以管理字典！', 'danger')
        return redirect(url_for('index'))
    
    try:
        ng_code = db.session.query(NgCode).get(id)
        if ng_code:
            db.session.delete(ng_code)
            db.session.commit()
            flash('NG Code删除成功！', 'success')
        else:
            flash('NG Code不存在！', 'danger')
    except Exception as e:
        flash(f'删除失败: {str(e)}', 'danger')
    
    return redirect(url_for('dictionary'))

# 添加站别
@app.route('/add_station', methods=['POST'])
def add_station():
    if 'role' not in session or session['role'] != 'engineer':
        flash('只有工程师权限可以管理字典！', 'danger')
        return redirect(url_for('index'))
    
    try:
        station_name = request.form['station_name']
        
        # 检查是否已存在
        existing = db.session.query(Station).filter_by(station_name=station_name).first()
        if existing:
            flash('该站别已存在！', 'danger')
            return redirect(url_for('dictionary'))
        
        # 添加新站别
        new_station = Station(
            station_name=station_name
        )
        db.session.add(new_station)
        db.session.commit()
        
        flash('站别添加成功！', 'success')
    except Exception as e:
        flash(f'添加失败: {str(e)}', 'danger')
    
    return redirect(url_for('dictionary'))

# 删除站别
@app.route('/delete_station/<int:id>')
def delete_station(id):
    if 'role' not in session or session['role'] != 'engineer':
        flash('只有工程师权限可以管理字典！', 'danger')
        return redirect(url_for('index'))
    
    try:
        station = db.session.query(Station).get(id)
        if station:
            db.session.delete(station)
            db.session.commit()
            flash('站别删除成功！', 'success')
        else:
            flash('站别不存在！', 'danger')
    except Exception as e:
        flash(f'删除失败: {str(e)}', 'danger')
    
    return redirect(url_for('dictionary'))

# 运行应用
if __name__ == '__main__':
    app.run(debug=True)
